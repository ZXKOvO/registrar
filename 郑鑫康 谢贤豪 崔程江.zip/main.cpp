import registrar;
import std;

int main()
{
    auto system = &Registrar::system;
    system().initialize();

    system().studentEnrollsInCourse("S001","CS101");
    system().studentEnrollsInCourse("S001","CS201");
    system().studentEnrollsInCourse("S001","MATH101");

    system().studentEnrollsInCourse("S002","CS101");
    system().studentEnrollsInCourse("S002","MATH101");

    system().studentEnrollsInCourse("S003","CS201");
    system().studentEnrollsInCourse("S003","MATH101");

    system().studentEnrollsInCourse("S004","CS101");
    system().studentEnrollsInCourse("S004","CS201");

    system().studentEnrollsInCourse("S005","CS201");

    std::println();

    system().courseRoster("CS101");
    system().courseRoster("CS201");
    system().courseRoster("MATH101");





    return 0;
}

